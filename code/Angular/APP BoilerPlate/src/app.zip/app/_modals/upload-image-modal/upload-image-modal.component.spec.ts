import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadImageModalComponent } from './upload-image-modal.component';

describe('TryoutModalComponent', () => {
  let component: UploadImageModalComponent;
  let fixture: ComponentFixture<UploadImageModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadImageModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadImageModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
