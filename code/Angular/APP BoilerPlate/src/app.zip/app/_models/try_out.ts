export class TryOut {
  address: string;
  age_group: string;
  days: string;
  time: string;
  requirements: string;
}
