
export class SkillSet {
  name: string;
  avatar: string;
  endorsements: string[];
}
