
export class User {
  email: string;
  name: string;
  avatar: string;
  password: string;
  last_login: string;
  subscription_expiration: string;
  id: string;
}
