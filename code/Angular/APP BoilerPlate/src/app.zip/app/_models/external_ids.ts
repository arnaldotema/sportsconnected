export class ExternalIds{
  zerozero: string;
}
