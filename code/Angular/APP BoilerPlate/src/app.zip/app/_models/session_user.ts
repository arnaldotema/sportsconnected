
export class SessionUser {
  token: string;
  _id: string;
  email: string;
  profile_id: string;
  user_type : string;
  avatar: string;
  name: string;
  team_id: string;
  team_avatar: string;
  team_acronym: string;
  team_name: string;
}
